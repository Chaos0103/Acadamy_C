#include<stdio.h>
#include"stack.h"

void StackInit(Stack* pstack)
{
	pstack->topIndex = -1;
}
int SIsEmpty(Stack* pstack)
{
	if (pstack->topIndex == -1)
		return TRUE;
	else
		return FALSE;
}
void SPush(Stack* pstack, Data data)
{
	pstack->topIndex++;
	if (pstack->topIndex == STACK_LEN)
	{
		printf("Index �ʰ�\n");
		return;
	}
	pstack->stackArr[pstack->topIndex] = data;
}

Data SPop(Stack* pstack)
{
	if (SIsEmpty(pstack))
	{
		printf("�����Ͱ� �����ϴ�\n");
		return FALSE;
	}

	Data rdata = pstack->stackArr[pstack->topIndex];

	pstack->topIndex--;

	return rdata;
}
Data SPeek(Stack* pstack)
{
	if (SIsEmpty(pstack))
	{
		printf("�����Ͱ� �����ϴ�\n"); 
		return FALSE;
	}

	Data rdata = pstack->stackArr[pstack->topIndex];

	return rdata;
}